var namespaces =
[
    [ "atomic", "namespaceatomic.html", null ],
    [ "VREF", "namespace_v_r_e_f.html", null ]
];