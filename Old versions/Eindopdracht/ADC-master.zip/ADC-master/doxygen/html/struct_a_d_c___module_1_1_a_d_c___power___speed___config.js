var struct_a_d_c___module_1_1_a_d_c___power___speed___config =
[
    [ "adacken", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#aacd348237348cbd25a301eaa0e530e3c", null ],
    [ "adhsc", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#a682dc49326d7aa8f035c38465ad81b4c", null ],
    [ "adiclk", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#ad78be17511df6fc33737b99ac547fe67", null ],
    [ "adiv", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#aa9b83273122af510c9e30c07856048ba", null ],
    [ "adlpc", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#aec8ad6e853744e6f6ed76a2c5856b7ef", null ],
    [ "adlsmp", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#af90390c1e525b71046411aba46f32e38", null ],
    [ "adlsts", "struct_a_d_c___module_1_1_a_d_c___power___speed___config.html#a59244a5cec2e66cb010de686d409e110", null ]
];