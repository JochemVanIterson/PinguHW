var searchData=
[
  ['p_5felems',['p_elems',['../class_ring_buffer_d_m_a.html#adf857179fa7ae20d8b439ee5794dc4c2',1,'RingBufferDMA']]],
  ['pin',['pin',['../struct_a_d_c___module_1_1_a_d_c___n_l_i_s_t.html#a1b635b49b8a53b9b5355af40be1455c9',1,'ADC_Module::ADC_NLIST']]]
];
