var searchData=
[
  ['low_5fspeed',['LOW_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2aaa486942a3788373f56f1955a6c97c9b',1,'LOW_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15daaa486942a3788373f56f1955a6c97c9b',1,'LOW_SPEED():&#160;ADC_Module.h']]]
];
