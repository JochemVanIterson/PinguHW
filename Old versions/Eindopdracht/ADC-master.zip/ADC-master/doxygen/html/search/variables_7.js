var searchData=
[
  ['savedsc1a',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8',1,'ADC_Module::ADC_Config']]],
  ['sc1a2channeladc0',['sc1a2channelADC0',['../class_a_d_c.html#aa3fc624721f8108ef8b77b45a857bdc6',1,'ADC']]],
  ['sc1a2channeladc1',['sc1a2channelADC1',['../class_a_d_c.html#ad1ed91f3ef9e283133455802c37c6501',1,'ADC']]]
];
