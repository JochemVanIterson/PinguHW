var searchData=
[
  ['calibrate',['calibrate',['../class_a_d_c___module.html#a037ab0589e2966cd07292c8186cad83e',1,'ADC_Module']]],
  ['checkdifferentialpins',['checkDifferentialPins',['../class_a_d_c___module.html#a80d29662a1a32a51fec606351685ebaf',1,'ADC_Module']]],
  ['checkpin',['checkPin',['../class_a_d_c___module.html#a9fd95a61d263a9d82918b50e81aee2e9',1,'ADC_Module']]],
  ['continuousmode',['continuousMode',['../class_a_d_c___module.html#a8b00e0669bbc7917544d4e2e543f1a27',1,'ADC_Module']]]
];
