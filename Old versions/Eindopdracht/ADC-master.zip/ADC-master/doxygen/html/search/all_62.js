var searchData=
[
  ['b_5fsize',['b_size',['../class_ring_buffer_d_m_a.html#ac1aeb3b7b58d93a74159d8b1def1193c',1,'RingBufferDMA']]]
];
