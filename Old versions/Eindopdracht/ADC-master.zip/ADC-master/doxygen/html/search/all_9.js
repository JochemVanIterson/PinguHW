var searchData=
[
  ['loadconfig',['loadConfig',['../class_a_d_c___module.html#a1bb50f669bbc41937fb5157abe2050ca',1,'ADC_Module']]],
  ['low_5fspeed',['LOW_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2aaa486942a3788373f56f1955a6c97c9b',1,'LOW_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15daaa486942a3788373f56f1955a6c97c9b',1,'LOW_SPEED():&#160;ADC_Module.h']]],
  ['license',['LICENSE',['../md_E:_Users_Villanueva_Arduino_libraries_ADC_LICENSE.html',1,'']]]
];
