var searchData=
[
  ['wrong_5fadc',['WRONG_ADC',['../_a_d_c___module_8h.html#a6e69c3b8cfd3360af320ac0bcf5b12eea52df2c8ae830ed21e0c2fc269087b3ec',1,'ADC_Module.h']]],
  ['wrong_5fpin',['WRONG_PIN',['../_a_d_c___module_8h.html#a6e69c3b8cfd3360af320ac0bcf5b12eeab578c19f4fab8e2bfeddc85fa17b5acf',1,'ADC_Module.h']]]
];
