var searchData=
[
  ['med_5fspeed',['MED_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2a9d9b800360e0fb88ba3d964b0b30feba',1,'MED_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15da9d9b800360e0fb88ba3d964b0b30feba',1,'MED_SPEED():&#160;ADC_Module.h']]]
];
