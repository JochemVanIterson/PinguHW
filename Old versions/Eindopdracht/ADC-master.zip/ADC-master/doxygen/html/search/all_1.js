var searchData=
[
  ['b_5fend',['b_end',['../class_ring_buffer_d_m_a.html#a738e6dc1618b83178f42638cd9b58662',1,'RingBufferDMA']]],
  ['b_5fstart',['b_start',['../class_ring_buffer_d_m_a.html#a1145aff44d38f6c8025f28bf082ec8b0',1,'RingBufferDMA']]],
  ['bandgap',['BANDGAP',['../_a_d_c___module_8h.html#ac8d2892dc23aba5d30e7013804d3429baec822af60bc7412ff73aecb3edffa55c',1,'ADC_Module.h']]],
  ['buffer',['buffer',['../class_ring_buffer_d_m_a.html#ac83104910c4245a4ef7e4fbe61eaf777',1,'RingBufferDMA']]]
];
