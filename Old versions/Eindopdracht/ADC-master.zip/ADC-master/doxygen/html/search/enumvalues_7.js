var searchData=
[
  ['ref_5f1v2',['REF_1V2',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9a77f9ecbcb2044013c35ce1156c14b3a0',1,'ADC_Module.h']]],
  ['ref_5f3v3',['REF_3V3',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9acbdca6103ed9d1895ad7cabeda125dac',1,'ADC_Module.h']]],
  ['ref_5fext',['REF_EXT',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9a5f3cc7cfab06012c0aa6a4b8a5a77161',1,'ADC_Module.h']]]
];
