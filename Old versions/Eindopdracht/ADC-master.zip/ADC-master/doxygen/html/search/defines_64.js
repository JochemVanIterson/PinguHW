var searchData=
[
  ['dma_5fbuffer_5fsize',['DMA_BUFFER_SIZE',['../_ring_buffer_d_m_a_8h.html#ac58748de79395a1751fc333bbc7ebd6b',1,'RingBufferDMA.h']]]
];
