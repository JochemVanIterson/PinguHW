var struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g =
[
    [ "adacken", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#ad7ec2bb831fffe09ee32ab016333520c", null ],
    [ "adhsc", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#a7370c04ccfbc3cd8a737adc411f98aa3", null ],
    [ "adiclk", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#a1c1f3ce97add93383d291b649ce2fe13", null ],
    [ "adiv", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#ae5551e139dfd008a8d312b6f3e2f5205", null ],
    [ "adlpc", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#a602f4cbc26dd63b4bdca7993c39ba48a", null ],
    [ "adlsmp", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#a64ce6312e1edd560ea12bb0e9b0caa62", null ],
    [ "adlsts", "struct_a_d_c___module_1_1_a_d_c___p_o_w_e_r___s_p_e_e_d___c_o_n_f_i_g.html#a4c7dcc888c03cfc29e1f8681bc1a33e4", null ]
];